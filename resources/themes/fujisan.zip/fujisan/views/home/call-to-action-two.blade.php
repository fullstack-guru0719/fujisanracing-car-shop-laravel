<div class="call-to-action-area">
        <div class="call-to-action-content-area bg-img" data-bg="{{ bagisto_asset('img/bg/bg-1.jpg') }}" style="background-image: url('{{ bagisto_asset('img/bg/bg-1.jpg') }}');">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="call-to-action-txt">
                            <h2>SERVICING PARTS <br> AVAILABLE HERE</h2>
                            <a href="{{ url()->to('/servicing') }}" class="btn btn-brand">Shop Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="call-to-action-image-area">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <img src="{{ bagisto_asset('img/icons/bg-car.png') }}" alt="Car">
                    </div>
                </div>
            </div>
        </div>
    </div>